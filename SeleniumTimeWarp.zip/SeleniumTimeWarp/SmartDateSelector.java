import java.time.Duration;
import java.time.Month;
import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SmartDateSelector {

    // Convert the calendar's month label to a Java Month value.
    static Month parseMonthName(String monthName) {
        HashMap<String, Month> months = new HashMap<String, Month>();
        months.put("January", Month.JANUARY);
        months.put("February", Month.FEBRUARY);
        months.put("March", Month.MARCH);
        months.put("April", Month.APRIL);
        months.put("May", Month.MAY);
        months.put("June", Month.JUNE);
        months.put("July", Month.JULY);
        months.put("August", Month.AUGUST);
        months.put("September", Month.SEPTEMBER);
        months.put("October", Month.OCTOBER);
        months.put("November", Month.NOVEMBER);
        months.put("December", Month.DECEMBER);

        Month parsedMonth = months.get(monthName);
        if (parsedMonth == null) {
            System.out.println("Invalid month: " + monthName);
        }
        return parsedMonth;
    }

    static void chooseCalendarDate(WebDriver driver, String targetYear, String targetMonth, String targetDay) {
        // Select the desired year from the dropdown.
        WebElement yearDropdown = driver.findElement(By.xpath("//select[@class='ui-datepicker-year']"));
        Select yearSelector = new Select(yearDropdown);
        yearSelector.selectByVisibleText(targetYear);

        // Navigate left or right until the target month is displayed.
        while (true) {
            String visibleMonth = driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
            Month expectedMonth = parseMonthName(targetMonth);
            Month currentMonth = parseMonthName(visibleMonth);
            int comparison = expectedMonth.compareTo(currentMonth);

            if (comparison < 0) {
                driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w']")).click();
            } else if (comparison > 0) {
                driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();
            } else {
                break;
            }
        }

        List<WebElement> calendarDays = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr//td//a"));
        for (WebElement day : calendarDays) {
            if (day.getText().equals(targetDay)) {
                day.click();
                break;
            }
        }
    }

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        try {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            driver.get("https://testautomationpractice.blogspot.com/");
            driver.manage().window().maximize();

            String targetYear = "2025";
            String targetMonth = "June";
            String targetDay = "15";

            driver.switchTo().frame("frame-one796456169");
            driver.findElement(By.xpath("//span[@class='icon_calendar']")).click();
            chooseCalendarDate(driver, targetYear, targetMonth, targetDay);
        } finally {
            driver.quit();
        }
    }
}
