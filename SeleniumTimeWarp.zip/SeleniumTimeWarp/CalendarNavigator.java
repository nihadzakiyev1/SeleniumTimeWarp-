import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CalendarNavigator {

    // Move forward through the calendar until the requested month and year appear.
    static void navigateToFutureDate(WebDriver driver, String targetYear, String targetMonth, String targetDay) {
        while (true) {
            String visibleMonth = driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
            String visibleYear = driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();

            if (visibleMonth.equals(targetMonth) && visibleYear.equals(targetYear)) {
                break;
            }
            driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();
        }
        clickDay(driver, targetDay);
    }

    // Move backward through the calendar until the requested month and year appear.
    static void navigateToPastDate(WebDriver driver, String targetYear, String targetMonth, String targetDay) {
        while (true) {
            String visibleMonth = driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
            String visibleYear = driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();

            if (visibleMonth.equals(targetMonth) && visibleYear.equals(targetYear)) {
                break;
            }
            driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w']")).click();
        }
        clickDay(driver, targetDay);
    }

    // Shared day-selection logic avoids repeating the same loop.
    static void clickDay(WebDriver driver, String targetDay) {
        List<WebElement> calendarDays = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr/td//a"));
        for (WebElement day : calendarDays) {
            if (day.getText().equals(targetDay)) {
                day.click();
                break;
            }
        }
    }

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        try {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            driver.get("https://jqueryui.com/datepicker/");
            driver.manage().window().maximize();
            driver.switchTo().frame(0);

            driver.findElement(By.xpath("//input[@id='datepicker']")).click();

            String targetYear = "2022";
            String targetMonth = "May";
            String targetDay = "10";

            // For a future date, call navigateToFutureDate instead.
            navigateToPastDate(driver, targetYear, targetMonth, targetDay);
        } finally {
            driver.quit();
        }
    }
}
