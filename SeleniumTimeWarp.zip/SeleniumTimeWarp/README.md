# SeleniumTimeWarp 📅

A Java + Selenium WebDriver practice project exploring two approaches to selecting dates in web calendar widgets.

## Examples
- **CalendarNavigator.java** — navigates backward or forward through the jQuery UI calendar and selects a day.
- **SmartDateSelector.java** — selects a year from a dropdown, compares months with Java's `Month` enum and `HashMap`, then selects a day inside an iframe.

## Tech stack
Java · Selenium WebDriver · ChromeDriver · XPath

## Run
Add Selenium WebDriver to your Java project, ensure Chrome is available, and run either Java class from your IDE. Both examples use publicly accessible practice websites. The locators are specific to those sites and may need updates if the pages change.
